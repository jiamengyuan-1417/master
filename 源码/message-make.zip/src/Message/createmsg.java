package Message;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;


public class createmsg {
	public boolean createMsg(File srcfilename,String path,String pathy) throws Exception{
		// ��ȡXML�ļ������document����
		Document document = null;
		try {
			DocumentBuilderFactory builderFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder builder = builderFactory.newDocumentBuilder();
			document = builder.parse(path);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		//��ȡ��Ϣ��ı���ֵ
		String zipName = srcfilename.getName();
		String[] zipNameAry = zipName.split("_");
			//ͨ�������޸���Ϣ��ı���ֵ
				document.getElementsByTagName("SJBS").item(0).getFirstChild().setTextContent(zipNameAry[4]);
				document.getElementsByTagName("YWLB").item(0).getFirstChild().setTextContent(zipNameAry[0]);
				document.getElementsByTagName("LCJDBH").item(0).getFirstChild().setTextContent(zipNameAry[1]);
				document.getElementsByTagName("FSDWBH").item(0).getFirstChild().setTextContent(zipNameAry[2]);
				document.getElementsByTagName("CFLJ").item(0).getFirstChild().setTextContent(zipName);
		// ������Ϣ�ļ�
		TransformerFactory transformerFactory = TransformerFactory
				.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource domSource = new DOMSource(document);

		// ���ñ�������
		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		
		String newmsgname = zipNameAry[2]+"_"+"0"+"_"+"3"+"_"+zipNameAry[4]+".xml";
		StreamResult result = new StreamResult(new FileOutputStream(pathy+newmsgname));
		// ��DOM��ת��Ϊ��Ϣ�ļ�
		transformer.transform(domSource, result);
		
		//�����Ƿ�ɹ����ɽ��ֵ
		boolean flag = false;
		if(new File(pathy).listFiles().length != 0) {
			flag = true;
		}
		return flag;
	}


}
