package updatexmlfile;

import java.text.SimpleDateFormat;
import java.util.Date;


public class GetAjbs {
	public static String getajbs(){
//		// 获取uuid的前12位，有字母，案件标识不能用
//		String uuid = UUID.randomUUID().toString().replace("-", "");
//		String uuid14 = uuid.substring(0,14);
		
		//获取时分秒 
        SimpleDateFormat simpleDateFormat;        
        simpleDateFormat = new SimpleDateFormat("HHmmSS");  
        Date date = new Date();    
        String str = simpleDateFormat.format(date);      

		System.out.println(str);
		
		return str;
	}

}
