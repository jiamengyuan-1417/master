package updatexmlfile;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class UpdateXml {
	 
	public String xmlUpdateDemo(File srcfilename,String pathy,String fileAbsolutePath) throws Exception {
		// 读取XML文件，获得document对象
		Document document = null;
		try {
			DocumentBuilderFactory builderFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder builder = builderFactory.newDocumentBuilder();
			document = builder.parse(fileAbsolutePath);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		// 获取标识节点
		//获取配置文件参数
			String properties = "config7.properties"; 
			LoadPopertiesFile.loadSqlFile(properties);
			//通过配置文件里的key-value修改XML值
			for (Map.Entry<String, String> entry : Constants.loadSqlMap.entrySet()) {
				//System.out.println("key= " + entry.getKey() + " and value= " + entry.getValue());
				String value = entry.getValue();
				NodeList ajbsNodes = document.getElementsByTagName(entry.getKey());
				for(int j=0;j<ajbsNodes.getLength();j++){
					Node subnode = ajbsNodes.item(j);
					// 修改案件标识元素值
					System.out.println(subnode.getFirstChild());
					System.out.println(subnode.getNodeValue());
					Node node = subnode.getFirstChild();
					if(node == null) {
						subnode.appendChild(document.createTextNode(entry.getValue()));
					}else {
						node.setNodeValue(value);
					}
					String itemName = ajbsNodes.item(j).getTextContent();
					System.out.println(itemName);
				}
			}
			//修改XML中SJBS
			String UUID = GUUid.getUUID();
			document.getElementsByTagName("SJBS").item(0).getFirstChild().setTextContent(UUID);
			//修改XML中PTTYBH
			String PTTYBH = GUUid.getPTTYBH();
			document.getElementsByTagName("PTTYBH").item(0).getFirstChild().setTextContent(PTTYBH);
			//修改XML中AJBH
			String AJBH = GUUid.getAJBH();
			document.getElementsByTagName("AJBH").item(0).getFirstChild().setTextContent(AJBH);
			
		// 保存xml文件
		TransformerFactory transformerFactory = TransformerFactory
				.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource domSource = new DOMSource(document);

		// 设置编码类型
		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		
		// 获取新的文件路径+名称:流程+流程节点+发送方+接收方+UUID+MD5
		String YWLB = document.getElementsByTagName("YWLB").item(0).getFirstChild().getTextContent();
		String LCJDBH = document.getElementsByTagName("LCJDBH").item(0).getFirstChild().getTextContent();
		String FSDWBH = document.getElementsByTagName("FSDWBH").item(0).getFirstChild().getTextContent();
		String JSDWBH = document.getElementsByTagName("JSDWBH").item(0).getFirstChild().getTextContent();
		String SJBS = document.getElementsByTagName("SJBS").item(0).getFirstChild().getTextContent();
//		String UUID = GUUid.getUUID();
//		document.getElementsByTagName("SJBS").item(0).getFirstChild().setTextContent(UUID);
		String MD5 = CreateMD5.getMD5String(srcfilename);
		
		//对接收方有多个的和XTXX表里值不规范的进行处置
		if(JSDWBH.contains(";")) {
			JSDWBH = JSDWBH.split(";")[0];
			System.out.println(JSDWBH+"该流程节点有多个接收方");
		}
		if(YWLB.length() != 5) {
			YWLB = YWLB.substring(0, 4);
			System.out.println(YWLB+"该流程节点有多个接收方");
		}
		String newfilename = YWLB+"_"+LCJDBH+"_"+FSDWBH+"_"+JSDWBH+"_"+SJBS+"_"+MD5;
		System.out.println(newfilename);
		
		StreamResult result = new StreamResult(new FileOutputStream(pathy+"\\YWXX.xml"));
		// 把DOM树转换为xml文件
		transformer.transform(domSource, result);
		
		return newfilename;
	}
}
