package updatexmlfile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class GetxmlAbsolutePath {
	//E:\\BJCMimp\\xml\\
	public static String unZipFiles(File zipFile, String descDir,String pdfDir) throws Exception {
        System.out.println("******************解压开始********************");
        File pathFile = new File(descDir);
        if (!pathFile.exists()) {
            pathFile.mkdirs();
        }
        @SuppressWarnings("resource")
		ZipFile zip = new ZipFile(zipFile,Charset.forName("GBK"));
        for (Enumeration entries = zip.entries(); entries.hasMoreElements();) {
            ZipEntry entry = (ZipEntry) entries.nextElement();
            String zipEntryName = entry.getName();
            InputStream in = zip.getInputStream(entry);
            String outPath = (descDir + "/" + zipEntryName).replaceAll("\\*", "/");
            // 判断路径是否存在,不存在则创建文件路径
            File file = new File(outPath.substring(0, outPath.lastIndexOf('/')));
            System.out.println(file + ":" + zipEntryName);
            if (!file.exists()) {
                file.mkdirs();
            }
            // 判断文件全路径是否为文件夹,如果是上面已经上传,不需要解压
            if (new File(outPath).isDirectory()) {
                continue;
            }
            OutputStream out = new FileOutputStream(outPath);
            byte[] buf1 = new byte[1024];
            int len;
            while ((len = in.read(buf1)) > 0) {
                out.write(buf1, 0, len);
            }
            if ((zipEntryName.trim().lastIndexOf("/")) == -1) {

            }
            in.close();
            out.close();
        }

        System.out.println("******************解压完毕********************");
        System.out.println("******************遍历文件夹******************");
        return traverse(zipFile,descDir,pdfDir);
    }
	
    
    /**
     * 文件夹遍历
     * @param path
     * @return 
     * @throws Exception
     */
    public static String traverse(File zipPath,String path,String pdfDir) throws Exception {
    	String filename = null;
    	long filesize = 0;
        System.out.println("path---->" + path);
        File zipName = zipPath.getAbsoluteFile();
        File file = new File(path);
        if (file.exists()) {
            File[] files = file.listFiles();
            if (files.length == 0) {
                System.out.println("文件夹是空的!");
                return "不存在xml文件";
            } else {
                for (File file2 : files) {
                    if (file2.isDirectory()) {//文件夹

                        traverse(zipName,file2.getAbsolutePath(),pdfDir);
                    } else if (file2.isFile()){//文件
                    	
                        if (file2.getName().endsWith(".xml")) {
                        	filename = file2.getAbsolutePath();
                            System.out.println("文件:" + file2.getAbsolutePath());
                        }
                        
                        if (file2.getName().endsWith(".pdf")||file2.getName().endsWith(".PDF")) {
                        	filename = file2.getAbsolutePath();
//                        	filesize = file2.length()/1024/1024;
//                        	if(filesize > 5) {
//                                System.out.println("路径" + zipName + "文件:" + filename + "大小" + file2.length() + "M");
//                        	}

                    		File source = new File(pdfDir);
                    		File dest = new File(filename);
                    		try {
                    			CopyPDF.copyFileUsingFileChannels(source,dest);
                    		} catch (IOException e) {
                    				//TODO Auto-generated catch block
                    			e.printStackTrace();
                    		}
                        }
                    }
                }
            }
        } else {
            System.out.println("文件不存在!");
        }
		return filename;
    }

}
