package updatexmlfile;

import java.text.SimpleDateFormat;
import java.util.Date;

public class GUUid {
    public static String getUUID() {
    	String UUID = java.util.UUID.randomUUID().toString().replace("-", "").toUpperCase();
		return UUID;
    }
    
    public static String getPTTYBH() {
    	
    	SimpleDateFormat simpleDateFormat; 
        simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmSS");
        
        Date date = new Date();    
        String str = simpleDateFormat.format(date); 
        long pttybh14 = generateRandomNumber(14);
        String pttybh = str + Long.toString(pttybh14);
        
		System.out.println(pttybh);
		
		return pttybh;
    }
    
    public static String getAJBH() {

		SimpleDateFormat simpleDateFormat; 
        simpleDateFormat = new SimpleDateFormat("yyyyMMddHH");
        
        Date date = new Date();    
        String str = simpleDateFormat.format(date); 
        long pttybh14 = generateRandomNumber(12);
        String ajbh = "A" + Long.toString(pttybh14) + str;
        
		System.out.println(ajbh);
		
		return ajbh;
    }
    
    protected static long generateRandomNumber(int n){
        if(n<1){
			throw new IllegalArgumentException("随机数位数必须大于0");
        }
			return (long)(Math.random()*9*Math.pow(10,n-1)) + (long)Math.pow(10,n-1);    
	}
}
