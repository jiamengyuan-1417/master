package updatexmlfile;

import java.io.File;
import java.io.FileOutputStream;

/**
 * @author jiamengyuan
 * @see 根据配置文件key-value形式修改测试包XML里的节点值
 *		生成文件MD5，修改数据标识；生成UUID
 *		根据XML中XTXX表修改六位包名
 * @param path:需要修改的XML测试包
 *        pathy_xml:解析的过程中的中间目录
 *        pathy_zip:修改之后生成的测试包位置
 * @version 1.0
 *
 */

public class Main {
	
	public static void main(String[] args) throws Exception {  
		//获取程序运行前当前时间
		long start = System.currentTimeMillis();
		// 获取数据包路径，注意替换\为//
		String path = "E://BJCMxml//";
		// 获取PDF路径，注意替换\为//
		String Dir = "E://BJCMpdf//";
		// 保存xml路径，替换\为\\
		String pathy_xml = "E:\\BJCMimp\\xml\\";
		// 保存zip路径，替换\为\\
		String pathy_zip = "E:\\BJCMimp\\data\\";
		// 获取文件夹中文件名称
		File[] array = (File[]) GetFilename.getFilename(path);
		// 获取文件夹中PDF路径
		File[] array1 = (File[]) GetFilename.getFilename(Dir);
		String pdfDir = array1[0].getAbsolutePath();
		// 依次修改文件中的案件标识
		for (int i = 0; i < array.length; i++) {
			if (array[i].isFile()) {
				//获取路径+文件名
				File srcfilename = array[i];
				System.out.println(srcfilename);
				String fileAbsolutePath = GetxmlAbsolutePath.unZipFiles(srcfilename, pathy_xml,pdfDir);
				// 调用修改xml文件方法
				UpdateXml xml = new UpdateXml();
				String newfilename = xml.xmlUpdateDemo(srcfilename,pathy_xml,fileAbsolutePath);
					    	  
		//打包文件到zip包
		FileOutputStream fos1 = new FileOutputStream(new File(pathy_zip+"/"+newfilename+".zip"));
		boolean isFile = true;
		boolean flag = FileToZip.fileToZip(pathy_xml, fos1, isFile);
        if(flag){  
            System.out.println("文件打包成功!");  
        }else{  
            System.out.println("文件打包失败!");  
        }
      }
    }
		//获取程序运行前当前时间
		long end = System.currentTimeMillis();
		long time = end - start;
		System.out.println("**********************************");
		System.out.println("所有数据包替换完毕，耗时：" + time + " ms");
  }
}
