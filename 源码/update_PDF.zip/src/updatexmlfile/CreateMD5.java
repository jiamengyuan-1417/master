package updatexmlfile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.codec.digest.DigestUtils;
/*
 * 用于生成MD5
 */
public class CreateMD5 {
	public static String getMD5String(File fileName){ 
		String md5 = null;
		try {
			md5 = DigestUtils.md5Hex(new FileInputStream(fileName)).toUpperCase();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return md5;  
	}
}
