package updatexmlfile;

import java.util.HashMap;
import java.util.Map;

public class Constants {
	  private Constants() {  
	    }  
	  
	    public static Map<String, String> loadSqlMap = new HashMap<String, String>(  
	            16);  

}
