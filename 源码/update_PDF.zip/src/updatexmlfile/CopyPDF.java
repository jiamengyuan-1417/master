package updatexmlfile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

public class CopyPDF {
	
//	public static void main(String[] args) {
//		File source = new File("E:\\BJCMpdf\\1111.pdf");
//		File dest = new File("E:\\BJCMpdf\\"+"12.pdf");
//		try {
//			copyFileUsingFileChannels(source,dest);
//		} catch (IOException e) {
//				TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
	/**
	 * @author jiamengyuan
	 * @param source
	 * @param dest
	 * @throws IOException
	 * 利用filechannel读取source，批量写入dest路径下的PDF
	 */
	@SuppressWarnings("resource")
	public static void copyFileUsingFileChannels(File source, File dest) throws IOException {    
        FileChannel inputChannel = null;    
        FileChannel outputChannel = null;    
    try {
        inputChannel = new FileInputStream(source).getChannel();
        outputChannel = new FileOutputStream(dest).getChannel();
        outputChannel.transferFrom(inputChannel, 0, inputChannel.size());
    } finally {
        inputChannel.close();
        outputChannel.close();
    }
}

}
