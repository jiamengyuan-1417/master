package log;
import java.io.File;

import java.io.IOException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.Colour;
import jxl.format.VerticalAlignment;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.apache.log4j.Logger;
public class MakeExcel {
	Logger logger = Logger.getLogger(MakeExcel.class);
	private static MakeExcel instance = new MakeExcel();
	public WritableWorkbook book;
	public Map.Entry entry;
	public String tempTime="";
	public MakeExcel() {
		try {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");//设置日期格式
			String url = MakeExcel.class.getProtectionDomain().getCodeSource().getLocation().getPath();
			String urlDecoder = URLDecoder.decode(url,"utf-8");
			urlDecoder = urlDecoder.substring(1,urlDecoder.lastIndexOf("/"))+"/"+df.format(new Date())+"_Errorlog.xls";
			logger.info("=====================================保存的路径： 是"+urlDecoder);
			this.book = Workbook.createWorkbook(new File(urlDecoder));
		} catch (IOException e) {
			System.out.println("[Error] 创建Excel失败");
			e.printStackTrace();
		}
	}
	public boolean WriteExcel(HashMap ErrorMaps, int page) {
		// 生成名为“第一页”的工作表，参数0表示这是第一页
		int pagetemp = page+1;
		WritableSheet sheet = book.createSheet("page_" + pagetemp, page);
		Label label;
		int row = 1;// 从第二行开始填入数据
		/** 首先进行数据的排序，调用Sort方法 */
		Object[] ErrorMapsResultKey = Sort(ErrorMaps);
		try {
			/** 设置各列的宽度 */
			sheet.setColumnView(0, 30);
			sheet.setColumnView(1, 20);
			sheet.setColumnView(2, 20);
			sheet.setColumnView(3, 100);
			sheet.setColumnView(4, 20);
			/** 第一行列名信息 */
			label = new Label(0, 0, "log名称", getDataCellFormat());
			sheet.addCell(label);
			label = new Label(1, 0, "log行号", getDataCellFormat());
			sheet.addCell(label);
			label = new Label(2, 0, "记录时间", getDataCellFormat());
			sheet.addCell(label);
			label = new Label(3, 0, "异常日志", getDataCellFormat());
			sheet.addCell(label);
			label = new Label(4, 0, "跟踪记录", getDataCellFormat());
			sheet.addCell(label);
			/** 填入数据 */
			for (Object s : ErrorMapsResultKey) {
				logger.info(s.toString() + "=>" + ErrorMaps.get(s).toString());
				String[] log = (String[])ErrorMaps.get(s);
				label = new Label(0, row, log[2]);
				sheet.addCell(label);
				//label = new Label(1, row, s.toString());
				label = new Label(1, row, log[3]);
				sheet.addCell(label);
				if(!"".equals(log[0]) && null != log[0]) {
					tempTime = log[0];
				} else if ("".equals(log[0])) {
					log[0] = tempTime;
				}
				label = new Label(2, row, log[0]);
				sheet.addCell(label);
				label = new Label(3, row++, log[1]);
				sheet.addCell(label);
			}
			/** 填入数据，参考代码 */
			/*
			 * Iterator iterator = ErrorMapsResult.entrySet().iterator(); while(iterator.hasNext()){ entry = (Map.Entry) iterator.next(); label = new Label(0, row,(entry.getKey().toString())); sheet.addCell(label); label = new Label(1, row++,(entry.getValue().toString())); sheet.addCell(label); }
			 */
		} catch (RowsExceededException e) {
			System.out.println("[Error] 数据插入Excel失败");
			e.printStackTrace();
		} catch (WriteException e) {
			System.out.println("[Error] 数据插入Excel失败");
			e.printStackTrace();
		}
		return true;
	}
	// 设置标注的格式为黄底红字
	public static WritableCellFormat getDataCellFormat() {
		WritableCellFormat wcf = null;
		try {
			WritableFont wf = new WritableFont(WritableFont.TIMES, 12, WritableFont.BOLD, false);
			// 字体颜色
			wf.setColour(Colour.BLACK);
			wcf = new WritableCellFormat(wf);
			// 对齐方式
			wcf.setAlignment(Alignment.LEFT);
			wcf.setVerticalAlignment(VerticalAlignment.CENTRE);
			// // 自动换行
			// wcf.setWrap(true);
		} catch (WriteException e) {
			e.printStackTrace();
		}
		return wcf;
	}
	public Object[] Sort(HashMap ErrorMaps) {
		HashMap<Integer, String> ErrorMapsResult = new HashMap<Integer, String>();
		Object[] keys = ErrorMaps.keySet().toArray();
		Comparator<Object> c = new Comparator<Object>() {
			@Override
			public int compare(Object o1, Object o2) {
				// TODO: add argument check yourself
				int a1 = (Integer) o1;
				int a2 = (Integer) o2;
				if (a1 > a2)
					return 1;
				if (a1 == a2)
					return 0;
				else
					return -1;
			}
		};
		Arrays.sort(keys, c);
		return keys;
	}
	public boolean closeExcel() {
		try {
			book.write();
			book.close();
		} catch (IOException e) {
			System.out.println("[Error] Excel关闭失败");
			e.printStackTrace();
		} catch (WriteException e) {
			System.out.println("[Error] Excel关闭失败");
			e.printStackTrace();
		}
		return false;
	}
	public static MakeExcel getInstance() {
		return instance;
	}
	public static void setInstance(MakeExcel instance) {
		MakeExcel.instance = instance;
	}
	public WritableWorkbook getBook() {
		return book;
	}
	public void setBook(WritableWorkbook book) {
		this.book = book;
	}
}
