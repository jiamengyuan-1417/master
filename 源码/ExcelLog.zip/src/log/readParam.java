package log;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.LinkedList;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;

import org.apache.log4j.Logger;

public class readParam{
	static Logger logger = Logger.getLogger(AnalysisParam.class);
	static LinkedList<File> list = new LinkedList<File>();
	static LinkedList<SmbFile> Smblist = new LinkedList<SmbFile>();
	static String LocateFile;
	static String RemoteFile;
	static SmbFile smbRemoteFile;
	static File localFile;
	
	static String isRepeat = "";
	static String isLocal = "";
	static String ip = "";
	static String filepath = "";
	static String un = "";
	static String pw = "";
	static String pw_bak = "";
	static String condition = "";
	static String encode = "";
    

    public static void main(String[] args) throws IOException {
    	/** 获取参数 */
		if (args.length < 6) {
			System.out.println("参数不正确");
		}
		String isRepeat = args[0];
		logger.info("isRepeat is "+isRepeat);
	  	String isLocal = args[1];
		logger.info("islocal is "+isLocal);
		String ip = args[2];
		logger.info("ip is "+ip);
		String filepath = args[3];
		logger.info("filepath is "+filepath);
		String un = args[4];
		logger.info("un is "+un);
		String pw = args[5];
		pw_bak = pw;
		try {
			pw = URLEncoder.encode(pw,"UTF-8");
		} catch (UnsupportedEncodingException e1) {
			logger.info("====================编码格式错误========================");
			e1.printStackTrace();
		} 
		logger.info("pw is "+pw);
		String condition = args[6];
		logger.info("condition is "+condition);
		String encode = args[7];
		logger.info("encode is "+encode);
		
//		isRepeat = "1";
//		logger.info("isRepeat is "+isRepeat);
//		isLocal = "1";
//		logger.info("islocal is "+isLocal);
////		ip = "172.16.11.40";
//		ip="127.0.0.1";
//		logger.info("ip is "+ip);
////		filepath = "\\\\172.16.176.100\\logs\\test\\";
//		filepath = "C:\\Users\\jiamengyuan\\Desktop\\log日志1\\";
//		logger.info("filepath is "+filepath);
//		un = "dev";
//		logger.info("un is "+un);
//		pw = "ceshi1";
//		pw_bak = pw;
//		try {
//			pw = URLEncoder.encode(pw,"UTF-8");
//		} catch (UnsupportedEncodingException e) {
//			logger.info("====================编码格式错误========================");
//			e.printStackTrace();
//		} 
//		logger.info("pw is "+pw);
//		condition = "[ERROR]";
//		//String condition = "a";
//		logger.info("condition is "+condition);
//		encode = "UTF-8";
//		logger.info("encode is "+encode);
		
		//这里做出更改遍历所有文件，存在linkedlist里面
		if (filepath.contains(".log")) {
			if (isLocal.equals("0")) {
				// smb://test:test@192.168.1.1/out/test.txt
				if ("default".equals(un)) {
					un = "";
				}
				if ("default".equals(pw)) {
					pw = "";
				}
				RemoteFile = filepath;
				RemoteFile = RemoteFile.replace('\\','/').substring(2);
				RemoteFile = "smb://" + un + ":" + pw + "@" + RemoteFile;
				logger.info("RemoteFile is "+RemoteFile);
				try {
					smbRemoteFile = new SmbFile(RemoteFile);
					
					String input[] = new String[10];
	                input[0] = isRepeat;
	                input[1] = isLocal;
	                input[2] = ip;
	                input[3] = filepath; //获取日志路径
	                input[4] = un;
	                input[5] = pw_bak;
	                input[6] = condition;
	                Integer a1 = 1;  //日志的数量
	                input[7] = a1.toString();
	                input[8] = smbRemoteFile.getName(); //获取日志名称
	                input[9] = encode; //获取编码集
	                try {
						AnalysisParam.AnalysisParam(input);
						AnalysisParam.LogNum ++; 
						AnalysisParam.RealLineNumber = 0;
					} catch (ClassNotFoundException e) {
						logger.info("=============AnalysisParam方法分析参数时出现错误==============");
						e.printStackTrace();
					} catch (IOException e) {
						logger.info("=============AnalysisParam方法分析参数时出现错误==============");
						e.printStackTrace();
					} catch (InterruptedException e) {
						logger.info("=============AnalysisParam方法分析参数时出现错误==============");
						e.printStackTrace();
					}
							
			        if (AnalysisParam.ErrorMaps.size() > 0 || AnalysisParam.page >0) {
						MakeExcel.getInstance().closeExcel();
					}
			        try {
						AnalysisParam.in.close();
					} catch (IOException e) {
						logger.info("eererwer");
						e.printStackTrace();
					}
					
				} catch (MalformedURLException e) {
					logger.info("=================create smbRemoteFile error==============");
					e.printStackTrace();
				}
				
			} else if (isLocal.equals("1")) {
				LocateFile = filepath;
				logger.info(LocateFile);
				localFile = new File(LocateFile);

			        
        	   	String input[] = new String[10];
                input[0] = isRepeat;
                input[1] = isLocal;
                input[2] = ip;
                input[3] = filepath; //获取日志路径
                input[4] = un;
                input[5] = pw;
                input[6] = condition;
                Integer a1 = 1;  //日志的数量
                input[7] = a1.toString();
                input[8] = localFile.getName(); //获取日志名称
                input[9] = encode; //获取编码集
                try {
					AnalysisParam.AnalysisParam(input);
					AnalysisParam.LogNum ++; 
					AnalysisParam.RealLineNumber = 0;
				} catch (ClassNotFoundException e) {
					logger.info("=============AnalysisParam方法分析参数时出现错误==============");
					e.printStackTrace();
				} catch (IOException e) {
					logger.info("=============AnalysisParam方法分析参数时出现错误==============");
					e.printStackTrace();
				} catch (InterruptedException e) {
					logger.info("=============AnalysisParam方法分析参数时出现错误==============");
					e.printStackTrace();
				}
		        
		        if (AnalysisParam.ErrorMaps.size() > 0 || AnalysisParam.page >0) {
					MakeExcel.getInstance().closeExcel();
				}
		        try {
					AnalysisParam.in.close();
				} catch (IOException e) {
					logger.info("eererwer");
					e.printStackTrace();
				}
			}
		} else {
	        if (isLocal.equals("0")) {
				// smb://test:test@192.168.1.1/out/test.txt
				if ("default".equals(un)) {
					un = "";
				}
				if ("default".equals(pw)) {
					pw = "";
				}
				RemoteFile = filepath;
				RemoteFile = RemoteFile.replace('\\','/').substring(1);
				RemoteFile = "smb://" + un + ":" + pw + "@" + ip + RemoteFile;
				RemoteFile = URLDecoder.decode(RemoteFile,"UTF-8");
				logger.info("username is "+un);
				logger.info("password is "+pw);
				System.out.println("username is "+un);
				System.out.println("password is "+pw);
				try {
					smbRemoteFile = new SmbFile(RemoteFile);
					if (smbRemoteFile.isDirectory()) {
						SmbFile[] Smbfile;		
						Smbfile = smbRemoteFile.listFiles();
				        for (int i = 0; i < Smbfile.length; i++) {
				            if (smbRemoteFile.isDirectory()) {
				            	//Smblist.add(Smbfile[i].getPath().toString());
				            	Smblist.add(Smbfile[i]);
				            	System.out.println((Smbfile[i]).getPath());
				            }
				        }
						
				        for(SmbFile a:Smblist){   //遍历所有日志文件
				        	   String input[] = new String[10];
				                input[0] = isRepeat;
				                input[1] = isLocal;
				                input[2] = ip;
				                input[3] = filepath+a.getName(); //获取日志路径
				                input[4] = un;
				                input[5] = pw_bak;
				                input[6] = condition;
				                Integer a1 = Smblist.size();  //日志的数量
				                input[7] = a1.toString();
				                input[8] = a.getName(); //获取日志名称
				                input[9] = encode; //获取编码集
				                try {
									AnalysisParam.AnalysisParam(input);
									AnalysisParam.LogNum ++; 
									AnalysisParam.RealLineNumber = 0;
								} catch (ClassNotFoundException e) {
									logger.info("=============AnalysisParam方法分析参数时出现错误==============");
									e.printStackTrace();
								} catch (IOException e) {
									logger.info("=============AnalysisParam方法分析参数时出现错误==============");
									e.printStackTrace();
								} catch (InterruptedException e) {
									logger.info("=============AnalysisParam方法分析参数时出现错误==============");
									e.printStackTrace();
								}
				        }
				        if (AnalysisParam.ErrorMaps.size() > 0 || AnalysisParam.page >0) {
							MakeExcel.getInstance().closeExcel();
						}
				        try {
							AnalysisParam.in.close();
						} catch (IOException e) {
							logger.info("eererwer");
							e.printStackTrace();
						}
					}
					
				} catch (MalformedURLException e) {
					logger.info("=================create smbRemoteFile error==============");
					e.printStackTrace();
				} catch (SmbException e) {
					logger.info("=================create smbRemoteFile error==============");
					e.printStackTrace();
				}
				
				
			} else if (isLocal.equals("1")) {
				LocateFile = filepath;
				logger.info(LocateFile);
				localFile = new File(LocateFile);
				if (localFile.isDirectory()) {
					File[] file = localFile.listFiles();
					
			        for (int i = 0; i < file.length; i++) {
			            if (!file[i].isDirectory()) {
			                
			                //filepath = file[i].getAbsolutePath();
			                list.add(file[i]);
			                System.out.println(file[i].getAbsolutePath());
			            }
		            }
			        for(File a:list){   //遍历所有日志文件
			        	   String input[] = new String[10];
			                input[0] = isRepeat;
			                input[1] = isLocal;
			                input[2] = ip;
			                input[3] = a.getAbsolutePath(); //获取日志路径
			                input[4] = un;
			                input[5] = pw;
			                input[6] = condition;
			                Integer a1 = list.size();  //日志的数量
			                input[7] = a1.toString();
			                input[8] = a.getName(); //获取日志名称
			                input[9] = encode; //获取编码集
			                try {
								AnalysisParam.AnalysisParam(input);
								AnalysisParam.LogNum ++; 
								AnalysisParam.RealLineNumber = 0;
							} catch (ClassNotFoundException e) {
								logger.info("=============AnalysisParam方法分析参数时出现错误==============");
								e.printStackTrace();
							} catch (IOException e) {
								logger.info("=============AnalysisParam方法分析参数时出现错误==============");
								e.printStackTrace();
							} catch (InterruptedException e) {
								logger.info("=============AnalysisParam方法分析参数时出现错误==============");
								e.printStackTrace();
							}
			        }
			        if (AnalysisParam.ErrorMaps.size() > 0 || AnalysisParam.page >0) {
						MakeExcel.getInstance().closeExcel();
					}
			        try {
						AnalysisParam.in.close();
					} catch (IOException e) {
						logger.info("eererwer");
						e.printStackTrace();
					}
		       } else {
		    	   
		       }
			}
		}
    }


}