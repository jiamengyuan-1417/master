package log;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileInputStream;

import org.apache.log4j.Logger;
public class AnalysisParam {
	static Logger logger = Logger.getLogger(AnalysisParam.class);
	/** 计算读取的行数 */
	static int lineNumber = 0;
	static int RealLineNumber = 0;
	/** 记录Excel页数，500行为一页 */
	static int page = 0;
	/** 从0开始计数 */
	static int calculateCount = 0;
	/** 500条创建新的第二个书签 */
	final static int count = 500;
	static HashMap<Integer, String[]> ErrorMaps = new HashMap<Integer, String[]>();
	static MakeExcel makeExcel;
	static String errorInfo = "";
	static String LocateFile;
	static String RemoteFile;
	static SmbFile smbRemoteFile;
	static File localFile;
	static boolean conditionFlag;
	static String[] errors = new String[2];
	static String errorTime="";
	static List<String> errorList = new ArrayList<String>();
	static BufferedReader in = null;
	static BufferedInputStream bis = null;
	static int LogNum = 1;
	static String isRepeat_all; //是全局的是否重复参数
	static String LogName;
	
	public AnalysisParam(){
		
	}
	
	public static boolean AnalysisParam (String[] args) throws ClassNotFoundException, IOException, InterruptedException {
		try {
			/** 获取参数 */
			if (args.length < 5) {
				System.out.println("参数不正确");
			}
			String isRepeat = args[0];
			isRepeat_all = isRepeat; 
			logger.info("isRepeat is "+isRepeat);
		  	String isLocal = args[1];
			logger.info("islocal is "+isLocal);
			String ip = args[2];
			logger.info("ip is "+ip);
			String filepath = args[3];
			logger.info("filepath is "+filepath);
			String un = args[4];
			logger.info("un is "+un);
			String pw = args[5];
			pw = URLEncoder.encode(pw,"UTF-8"); 
			logger.info("pw is "+pw);
			String condition = args[6];
			logger.info("condition is "+condition);
			int MaxLogNum = Integer.parseInt(args[7]);
			logger.info("MaxLogNum is "+MaxLogNum);
			LogName = args[8];
			String encode = args[9];
			logger.info("encode is "+encode);
//			String isRepeat = "0";
//			logger.info("isRepeat is "+isRepeat);
//			String isLocal = "1";
//			logger.info("islocal is "+isLocal);
//			String ip = "172.16.31.81";
//			logger.info("ip is "+ip);
//			//String filepath = "\\\\172.16.7.230\\logs3\\HDMS.log";
//			String filepath = "C:\\Users\\Administrator\\Desktop\\log日志\\wsfwzx_stdout.2020-04-24.log";
//			logger.info("filepath is "+filepath);
//			String un = "administrator";
//			logger.info("un is "+un);
//			String pw = "123qwe!@#";
//			pw = URLEncoder.encode(pw,"UTF-8"); 
//			logger.info("pw is "+pw);
//			String condition = "[ERROR]";
//			//String condition = "a";
//			logger.info("condition is "+condition);
			
			//这里做出更改遍历所有文件，存在linkedlist里面
			
			
			
			
			bis = null;
			if (isLocal.equals("0")) {
				// smb://test:test@192.168.1.1/out/test.txt
				if ("default".equals(un)) {
					un = "";
				}
				if ("default".equals(pw)) {
					pw = "";
				}
				RemoteFile = filepath;
				RemoteFile = RemoteFile.replace('\\','/').substring(1);
				RemoteFile = "smb://" + un + ":" + pw + "@" + ip + RemoteFile;
				logger.info("RemoteFile is "+RemoteFile);
				smbRemoteFile = new SmbFile(RemoteFile);
				//smbRemoteFile = new SmbFile("smb://HdmsUser:"+pw+"@172.16.5.81/logs/vms.log");
				//smbRemoteFile = new SmbFile("smb://HdmsUser:"+pw+"@"+RemoteFile);
				SmbFileInputStream smbFileInputStream = new SmbFileInputStream(smbRemoteFile);
				logger.info(smbFileInputStream.available());
				bis = new BufferedInputStream(new SmbFileInputStream(smbRemoteFile));
			} else if (isLocal.equals("1")) {
				LocateFile = filepath;
				System.out.println(LocateFile);
				localFile = new File(LocateFile);
				bis = new BufferedInputStream(new FileInputStream(localFile));
			}
			in = new BufferedReader(new InputStreamReader(bis, encode), 10 * 1024 * 1024);// 10M缓存
			String[] analysisParameter = AnalysisParameter(condition);
			while ((errorInfo = in.readLine()) != null) {
				lineNumber++;
				RealLineNumber++;
				boolean flag = IsContain(errorInfo,analysisParameter);//解析多个参数，用于匹配字符串用
				if (flag) { // 这个标示符要从log中粘贴进来
					clearError();
					logger.info(errorInfo);
					
					if(errorInfo.indexOf('[')<0) {
						errorTime = "无";
					} else if(errorInfo.indexOf('[')>0 && errorInfo.indexOf('[')<25){
						errorTime = errorInfo.substring(0,errorInfo.indexOf('[')).trim();
						Pattern p2 = Pattern.compile("(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}.\\d{3})");
				        Matcher m2 = p2.matcher(errorTime);
				        if (m2.matches()) {
				        	errorTime = m2.group(1);
							//System.out.println(errorTime);
						} else {
							Pattern p1 = Pattern.compile("(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2})");
					        Matcher m1 = p1.matcher(errorTime);
					        if (m1.matches()) {
					        	errorTime = m1.group(1);
								//System.out.println(errorTime);
							} else {
								errorTime = "";
							}
						}
					} else {
						errorTime = errorInfo.substring(0,19).trim();
						Pattern p2 = Pattern.compile("(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2})");
				        Matcher m2 = p2.matcher(errorTime);
				        if (m2.matches()) {
				        	errorTime = m2.group(1);
							//System.out.println(errorTime);
						}else {
							errorTime = "";
						}
					}
					//去掉前面的内容
					//errorInfo = errorInfo.substring(errorInfo.indexOf(condition)).trim();
					if(condition.contains("[")) {
						Pattern p = Pattern.compile(".+\\[(ERROR|INFO|WARN)\\](.+)");
				        Matcher m = p.matcher(errorInfo);
				        if (m.matches()) {
				        	errorInfo = m.group(2);
				        	if(errorInfo.length() > 1000) {
				        		errorInfo = errorInfo.substring(0, 400);
				        	}
							logger.info(errorInfo);
						}else {
							logger.info("no matches!!"+errorInfo);
						}
					}else{
						Pattern p = Pattern.compile(".+(ERROR|INFO|WARN)(.+)");
				        Matcher m = p.matcher(errorInfo);
				        if (m.matches()) {
				        	errorInfo = m.group(2);
				        	if(errorInfo.length() > 1000) {
				        		errorInfo = errorInfo.substring(0, 400);
				        	}
							logger.info(errorInfo);
						}else {
							logger.info("no matches!!"+errorInfo);
						}
					}
					
					//如果集合中已经包含内容了，则不放入集合
			        if ("1".equals(isRepeat)) {
			        	if (!errorList.contains(errorInfo)) {
			        		if (!WriteExcel()) {
				        		break;
				        	}
						}
			        } else {
			        	if (!WriteExcel()) {
			        		break;
			        	}
			        }
			        
					
				}
			}
			if (ErrorMaps.size() > 0 && LogNum == MaxLogNum) { //小于500行的错误这里写入
				if (!makeExcel()) {
					System.out.println("调用Excel出现错误");
					return false;
				}
			}
			/*if (ErrorMaps.size() > 0 || page >0) {
				MakeExcel.getInstance().closeExcel();
			}
			in.close();*/
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
			
		}
		return true;
		
	}
	public static boolean makeExcel() {
		makeExcel = MakeExcel.getInstance();
		if (makeExcel.WriteExcel(ErrorMaps, page)) {
			calculateCount = 0;   //500条记录请0一次
			return true;
		} else {
			System.out.println("写入第" + page + "页数据时出现错误");
			return false;
		}
	}
	
	public static boolean IsContain(String errorInfo,String[] parameter) {
		for (String tempParameter:parameter) {
			if (errorInfo.contains(tempParameter)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * 根据逗号分隔过滤条件
	 */
	public static String[] AnalysisParameter(String condition){
		
		String[] parameter = condition.split(",");
		logger.info(parameter.length);
		return parameter;
	}
	
	//errors是个数组，用来记录一条错误信息
	public static void clearError() {
		for(int i =0;i<errors.length;i++){
			errors[i] = "";
		}
	}
	
	public static boolean WriteExcel(){
		String[] errors = new String[4];
		errors[0]=errorTime;
		errors[1]=errorInfo;
		errors[2]=LogName;
		if ("1".equals(isRepeat_all)) {
			errorList.add(errorInfo);
		}
		
		Integer x = RealLineNumber;
		errors[3]=x.toString();
    	ErrorMaps.put(lineNumber, errors);
		calculateCount++;
		logger.info(calculateCount);
		logger.info(count);
		if (calculateCount == count) {
			if (!makeExcel()) {
				System.out.println("调用Excel出现错误");
				return false;
			}
			page++;
			calculateCount = 0;
			ErrorMaps.clear();
			
		}
		return true;
	}
}
