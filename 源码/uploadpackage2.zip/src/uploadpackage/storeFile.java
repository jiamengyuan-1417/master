package uploadpackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

/**
 * @author jiamengyuan
 * @see 循环调用run_encrypt_upload.bat上传工具上传到每个测试包服务器发送方目录
 *                     支持加密
 * @param configpath:run_encrypt_upload.bat的配置信息
 *        batpath:工具位置
 *        zippath:测试包位置
 * @version 1.0
 *
 */

public class storeFile {
	public static void clickBat () {
		String configpath = "F:\\eclipse\\uploadpackage2\\config.ini";
		String batpath = "F:\\eclipse\\uploadpackage2\\run_encrypt_upload.bat";
		String zippath = "F:\\eclipse\\uploadpackage2\\uploadzip";
		String jiamizippath = "F:\\eclipse\\uploadpackage2\\uploadzip\\jiami";
		
        FileInputStream fis = null;
        OutputStream fos;
        Properties pp;
        
        
        // 初始化并加载读取的文件
        try {
        	//如要加密请把zippath改为jiamizippath
    		File[] array = (File[]) GetFilename.getFilename(jiamizippath);
    		
    		for(int i = 0;i < array.length;i++) {
    			
                //获取接收方
    			boolean Filetype = array[i].getName().endsWith(".zip");
    			String zipname = array[i].getName();
    			System.out.println(zipname);
    			if(!Filetype) {
    				System.out.println("此文件为加密文件夹");
    				continue;
    			}else{
    				String[] zipname2 = zipname.split("_");
        			System.out.println(zipname2[1]);
        			String str = File.separator;
        			String str1 = File.pathSeparator;
        			System.out.println(str+"________________________________"+str1);
        			
        			//解析文件
            		pp = new Properties();
                    fis = new FileInputStream(configpath);
                    pp.load(fis);
                    
                    // 修改config.ini文件里的sendPath
                    fos = new FileOutputStream(configpath);
                    
                    if(zipname2[2].equals("11022300000000")||zipname2[2].equals("11000000000000")||zipname2[2].equals("11022816030000")) {
                    	pp.setProperty("sendPath", "/data/ftp/bjcm/gaj/send/data");// 修改路径值
                    	pp.setProperty("zip_name", zipname);// 修改包名值
                    }else if(zipname2[2].equals("110112")||zipname2[2].equals("110000")){
                    	pp.setProperty("sendPath", "/data/ftp/bjcm/jcy/send/data");// 修改路径值
                    	pp.setProperty("zip_name", zipname);// 修改包名值
                    }else if(zipname2[2].equals("18")||zipname2[2].equals("1")) {
                    	pp.setProperty("sendPath", "/data/ftp/bjcm/fy/send/data");// 修改路径值
                    	pp.setProperty("zip_name", zipname);// 修改包名值
                    }else if(zipname2[2].equals("11022326000000")||zipname2[2].equals("11000047000000")||zipname2[2].equals("11010530030000")){
                    	pp.setProperty("sendPath", "/data/ftp/bjcm/kss/send/data");// 修改路径值
                    	pp.setProperty("zip_name", zipname);// 修改包名值
                    }else if(zipname2[2].equals("110112040101090001")||zipname2[2].equals("110000020101010001")||zipname2[2].equals("100028179")) {
                    	pp.setProperty("sendPath", "/data/ftp/bjcm/sfj/send/data");// 修改路径值
                    	pp.setProperty("zip_name", zipname);// 修改包名值
                    }else if(zipname2[2].equals("73878031185de329fa6876725c100001")||zipname2[2].equals("73878031185de329fa6876725c100000")||zipname2[2].equals("jdj11")){
                    	pp.setProperty("sendPath", "/data/ftp/bjcm/sfj/send/data");// 修改路径值
                    	pp.setProperty("zip_name", zipname);// 修改包名值
                    }else{
                    	System.out.println("此发送方无效");
                    }
                    
                  //关闭流
                    pp.store(fos, null);
                    fos.close();
                    
                    //运行bat文件上传zip包
                    if(i != array.length) {
                    	Process ps = Runtime.getRuntime().exec("cmd /c start "+batpath);
                        ps.waitFor();
                    }
                    
                    Thread.sleep(1000);
                    
    			}
    		}
    		
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

	}
	
	public static void jiami() throws Exception {
		String batpath = ".\\encrypt_traversal.bat";
		Process ps = Runtime.getRuntime().exec("cmd /c start "+batpath);
        ps.waitFor();
	}
	
	public static void main(String[] args) {
		//如果需要加密，可开启这个方法，直接把注释的//去掉就行
		try {			
			jiami();
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
//		clickBat();
		
	}
}
