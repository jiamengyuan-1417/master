package uploadpackage;


import java.io.File;

public class GetFilename {
	public static Object getFilename(String path) throws Exception {
		// 获取文件路径
		File file = new File(path);
		if (!file.exists()) {
			System.out.println(path + " not exists");
			return null;
		}

		// 获取文件夹列表
		File[] array = file.listFiles();
			 
		return array;
	}
}
